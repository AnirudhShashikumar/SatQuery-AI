GeoVision SatQuery mission report package

Request ID: 19feb46a-44ca-47f4-8c13-c5502f0d8906
Task: cross_modal_analysis
All evidence is model-generated or deterministic heuristic output as labelled; it is not ground truth.
No original uploads, API keys, model-cache paths, local filesystem paths, environment values, or hidden reasoning are included.
