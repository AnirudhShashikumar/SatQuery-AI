GeoVision SatQuery mission report package

Request ID: 81496f78-f1f2-470e-92b0-657cc4947325
Task: cross_modal_analysis
All evidence is model-generated or deterministic heuristic output as labelled; it is not ground truth.
No original uploads, API keys, model-cache paths, local filesystem paths, environment values, or hidden reasoning are included.
